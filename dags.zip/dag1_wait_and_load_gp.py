from airflow.sdk import dag, task
from airflow.providers.standard.sensors.filesystem import FileSensor
from airflow.models import Variable
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime, timedelta

@dag(
    schedule=None,
    start_date=datetime(2026, 6, 1),
    catchup=False,
    tags=['greenplum', 'etl'],
    description='Ожидание CSV и загрузка в Greenplum',
)

def dag1_load_to_greenplum():
    wait_for_csv = FileSensor(
    task_id='wait_for_csv',
    filepath='data/etl/csv/order_10000000.csv',
    fs_conn_id='fs_etl',
    poke_interval=10,
    timeout=600,
    )

    @task
    def create_ext_table():
        hook = PostgresHook(postgres_conn_id='greenplum_conn')
        etl = Variable.get('etl_server')
        port = Variable.get('gpfdist_port')
        hook.run(f"""
            DROP EXTERNAL TABLE IF EXISTS ext_orders;
            CREATE READABLE EXTERNAL TABLE ext_orders (
                order_id TEXT, person_id TEXT, order_date TEXT,
                status TEXT, total_amount TEXT, currency TEXT,
                payment_method TEXT, shipping_method TEXT, notes TEXT
            )
            LOCATION ('gpfdist://{etl}:{port}/order_10000000.csv')
            FORMAT 'CSV' (DELIMITER ',' HEADER);
        """)
    
    @task
    def truncate_target():
        hook = PostgresHook(postgres_conn_id='greenplum_conn')
        hook.run("TRUNCATE TABLE orders_gp;")

    @task
    def create_target_table():
        hook = PostgresHook(postgres_conn_id='greenplum_conn')
        hook.run("""
            CREATE TABLE IF NOT EXISTS orders_gp (
                order_id INT, person_id INT, order_date DATE,
                status TEXT, total_amount NUMERIC, currency TEXT,
                payment_method TEXT, shipping_method TEXT, notes TEXT
            ) DISTRIBUTED BY (order_id);""")
    
    @task
    def load_data():
        hook = PostgresHook(postgres_conn_id='greenplum_conn')
        hook.run("""
            INSERT INTO orders_gp
            SELECT order_id::INT, person_id::INT, order_date::DATE,
                   status, total_amount::NUMERIC, currency,
                   payment_method, shipping_method, notes
            FROM ext_orders;
        """)
    
    @task
    def set_loaded_flag():
        Variable.set('gp_loaded', 'true')
    
    wait_for_csv >> create_ext_table() >> create_target_table() >> truncate_target() >> load_data() >> set_loaded_flag()

dag1_load_to_greenplum()