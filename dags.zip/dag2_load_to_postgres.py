from airflow.decorators import dag, task
from airflow.sensors.python import PythonSensor
from airflow.models import Variable
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime, timedelta

@dag(
    schedule=None,
    start_date=datetime(2026, 6, 1),
    catchup=False,
    tags=['postgres', 'etl'],
    description='Загрузка данных в PostgreSQL после завершения DAG1',
)
def dag2_load_to_postgres():

    wait_for_gp = PythonSensor(
        task_id='wait_for_gp_loaded',
        python_callable=lambda: Variable.get('gp_loaded', default_var='false') == 'true',
        poke_interval=10,
        timeout=600,
    )

    @task
    def create_pg_table():
        hook = PostgresHook(postgres_conn_id='postgres_conn')
        hook.run("""
            CREATE TABLE IF NOT EXISTS orders_pg (
                order_id INT, person_id INT, order_date DATE,
                status TEXT, total_amount NUMERIC, currency TEXT,
                payment_method TEXT, shipping_method TEXT, notes TEXT
            );
        """)

    @task
    def load_from_gp_to_pg():
        pg_hook = PostgresHook(postgres_conn_id='postgres_conn')
        gp_hook = PostgresHook(postgres_conn_id='greenplum_conn')
        gp_conn = gp_hook.get_connection('greenplum_conn')

        pg_hook.run(f"""
            INSERT INTO orders_pg
            SELECT * FROM dblink(
                'host={gp_conn.host} port={gp_conn.port} dbname={gp_conn.schema} user={gp_conn.login} password={gp_conn.password}',
                'SELECT * FROM orders_gp'
            ) AS t(
                order_id INT, person_id INT, order_date DATE,
                status TEXT, total_amount NUMERIC, currency TEXT,
                payment_method TEXT, shipping_method TEXT, notes TEXT
            );
        """)

    wait_for_gp >> create_pg_table() >> load_from_gp_to_pg()


dag2_load_to_postgres()