from airflow.sdk import dag
from airflow.providers.standard.operators.empty import EmptyOperator
from datetime import datetime

@dag(
    dag_id='pyatunin_first_dag', 
     schedule='*/40 * * * *',
    start_date=datetime(2026, 5, 21),
    catchup=False
)

def first_dag():
    task_1 = EmptyOperator(task_id="dummy_task_1")
    task_2 = EmptyOperator(task_id="dummy_task_2")

    task_1 >> task_2
    
first_dag()