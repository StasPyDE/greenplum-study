from airflow.sdk import dag
from airflow.providers.standard.sensors.external_task import ExternalTaskSensor
from datetime import datetime
from datetime import timedelta

def get_latest_20min_interval(logical_date):
    current_minute = logical_date.minute
    rounded_minute = (current_minute // 20) * 20
    return logical_date.replace(minute=rounded_minute, second=0, microsecond=0)

@dag(
    dag_id='pyatunin_third_dag',
    schedule='*/55 * * * *',
    start_date=datetime(2026, 5, 21),
    catchup=False,
)

def third_dag():
    first_sensor = ExternalTaskSensor(
        task_id = 'wait_for_dag1_start_task',
        external_dag_id = 'pyatunin_first_dag',
        external_task_id="dummy_task_1",
        allowed_states=['success'],
        failed_states=['failed'],
        mode='poke',
        poke_interval=60,
        timeout=600,
        execution_date_fn=get_latest_20min_interval
    )

    second_sensor = ExternalTaskSensor(
        task_id = 'wait_for_dag2_start_task',
        external_dag_id = 'pyatunin_second_dag',
        external_task_id = None,
        allowed_states=['success'],
        failed_states=['failed'],
        mode='poke',
        poke_interval=60,
        timeout=600,
        execution_date_fn=get_latest_20min_interval
    )

    [first_sensor, second_sensor]

third_dag()