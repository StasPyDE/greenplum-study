from airflow.sdk import dag
from datetime import datetime
from airflow.providers.standard.operators.bash import BashOperator

@dag(
    dag_id='pyatunin_second_dag',
    schedule='*/20 * * * *',
    start_date=datetime(2026, 5, 21),
    catchup=False
)

def second_dag():
    task_1 = BashOperator(
        task_id="bash_task_1",
        bash_command="sleep 30 && echo 'Task 1 completed'"
    )
    task_2 = BashOperator(
        task_id="bash_task_2",
        bash_command="sleep 30 && echo 'Task 2 completed'"
    )
    task_3 = BashOperator(
        task_id="bash_task_3",
        bash_command="sleep 30 && echo 'Task 3 completed'"
    )

    [task_1, task_2, task_3]

second_dag()